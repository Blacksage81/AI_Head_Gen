"""Runs INSIDE the landmark venv (Python 3.12 + MediaPipe), never inside
Blender's own process. Launched as a subprocess by landmark_client.py.

Deliberately stdlib-only on the server side (http.server, json, urllib) so
the venv only ever needs `mediapipe` installed - no Flask, no extra
dependency to go wrong.
"""

import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import urlretrieve

import mediapipe as mp
from mediapipe.tasks import python as mp_tasks
from mediapipe.tasks.python import vision as mp_vision


_MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/face_landmarker/"
    "face_landmarker/float16/latest/face_landmarker.task"
)

_landmarker = None
_landmarker_lock = threading.Lock()


def _ensure_model(cache_dir: Path) -> Path:
    cache_dir.mkdir(parents=True, exist_ok=True)
    model_path = cache_dir / "face_landmarker.task"
    if not model_path.exists():
        urlretrieve(_MODEL_URL, model_path)
    return model_path


def _get_landmarker(cache_dir: Path):
    global _landmarker
    with _landmarker_lock:
        if _landmarker is None:
            model_path = _ensure_model(cache_dir)
            base_options = mp_tasks.BaseOptions(model_asset_path=str(model_path))
            options = mp_vision.FaceLandmarkerOptions(
                base_options=base_options,
                running_mode=mp_vision.RunningMode.IMAGE,
                num_faces=1,
            )
            _landmarker = mp_vision.FaceLandmarker.create_from_options(options)
    return _landmarker


class Handler(BaseHTTPRequestHandler):
    cache_dir = None  # set in main()

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self._send_json(200, {"status": "ok"})
        else:
            self._send_json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/landmarks":
            self._send_json(404, {"error": "not found"})
            return

        length = int(self.headers.get("Content-Length", 0))
        try:
            body = json.loads(self.rfile.read(length))
            image_path = body["image_path"]

            landmarker = _get_landmarker(self.cache_dir)
            mp_image = mp.Image.create_from_file(image_path)
            result = landmarker.detect(mp_image)

            if not result.face_landmarks:
                self._send_json(200, {"landmarks": [], "count": 0})
                return

            # Single-face (num_faces=1) - take the first detected face.
            points = [[lm.x, lm.y, lm.z] for lm in result.face_landmarks[0]]
            self._send_json(200, {
                "landmarks": points,
                "count": len(points),
                "image_width": mp_image.width,
                "image_height": mp_image.height,
            })
        except Exception as exc:
            self._send_json(500, {"error": str(exc)})

    def log_message(self, format, *args):
        pass  # keep stdout quiet; errors still surface via JSON responses


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    cache_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path.home() / ".ahg_cache"
    Handler.cache_dir = cache_dir

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.serve_forever()


if __name__ == "__main__":
    main()
