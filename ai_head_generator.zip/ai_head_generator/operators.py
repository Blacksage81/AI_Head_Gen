"""Operators for AI Head Generator.

Contains a reusable modal-operator-plus-background-thread base class, since
this pattern is needed everywhere the add-on does real work (environment
install, generation) and must never block Blender's UI thread. Heavy work
runs off-thread; only queue draining and bpy calls happen in modal(), on
the main thread, where they're safe.
"""

import json
import platform
import queue
import re
import sys
import tarfile
import threading
import time
import urllib.request

import numpy as np

import bpy
from bpy_extras.io_utils import ImportHelper

from .preferences import get_prefs
from . import landmark_client
from . import gnm_client


# ---------------------------------------------------------------------------
# Reusable non-blocking background-operator base
# ---------------------------------------------------------------------------

def _kill_stale_processes_in_dir(target_dir):
    """Best-effort: kill any process whose executable lives inside
    target_dir. Handles orphaned server subprocesses from a previous
    Blender session that weren't cleanly shut down - e.g. Blender was
    force-quit, crashed, or was just closed without disabling the
    add-on first, none of which reliably calls our unregister() cleanup.
    A subprocess.Popen'd server doesn't automatically die with Blender,
    so it can outlive the session and hold DLLs/.pyd files locked,
    blocking a later reinstall. Failures here are silently ignored -
    this is a safety net, not something that should introduce new
    failure modes of its own."""
    if sys.platform != "win32":
        return  # TODO: macOS/Linux equivalent (pgrep/pkill by path) if needed
    import subprocess
    try:
        script = (
            f"Get-CimInstance Win32_Process | "
            f"Where-Object {{ $_.ExecutablePath -like '*{target_dir}*' }} | "
            f"ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force }}"
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            capture_output=True, text=True, timeout=15,
        )
        time.sleep(0.5)  # give the OS a moment to actually release the file handle
    except Exception:
        pass


def _force_remove_dir(target_dir):
    """Removes target_dir using PowerShell rather than Python's own
    shutil.rmtree (what venv.EnvBuilder's clear=True uses internally).
    shutil.rmtree isn't long-path-safe on Windows by default and fails
    with WinError 145 against deeply-nested paths - jupyterlab's asset
    folders (@jupyterlab/galata-extension/static/...) are exactly the
    kind of structure that triggers this. The \\\\?\\ prefix tells
    Windows to bypass the 260-character MAX_PATH limit entirely."""
    from pathlib import Path
    target_dir = Path(target_dir)
    if not target_dir.exists():
        return
    if sys.platform != "win32":
        import shutil
        shutil.rmtree(target_dir, ignore_errors=True)
        return
    import subprocess
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             f'Remove-Item -Recurse -Force -LiteralPath "\\\\?\\{target_dir}"'],
            capture_output=True, text=True, timeout=60,
        )
    except Exception:
        pass


class AHG_ModalBackgroundOperator(bpy.types.Operator):
    """Base class: runs self.run_background() in a thread, polls a queue
    on a timer, and only ever touches bpy state from modal() on the main
    thread. Subclasses implement run_background(queue, stop_event) and
    put dicts like {"status": "...", "progress": 0-100} on the queue,
    finishing with {"done": True} or {"error": "..."}.
    """

    _timer = None
    _thread = None
    _queue = None
    _stop_event = None

    def run_background(self, q, stop_event):
        raise NotImplementedError

    def on_done(self, context):
        """Optional hook for subclasses: called on the main thread once
        the background thread reports completion."""
        pass

    def on_progress(self, context, status, progress):
        """Default: write to the scene-level props the Generate panel
        reads. Preferences-driven operators (environment installs)
        override this to update AddonPreferences fields instead, since
        their feedback belongs in the window the button lives in."""
        props = context.scene.ahg_props
        if status is not None:
            props.status = status
        if progress is not None:
            props.progress = progress

    def on_error(self, context, message):
        """Default: same scene-level props as on_progress."""
        props = context.scene.ahg_props
        props.status = f"Error: {message}"
        props.is_running = False

    def invoke(self, context, event):
        self._queue = queue.Queue()
        self._stop_event = threading.Event()
        self._thread = threading.Thread(
            target=self._run_wrapper, args=(self._queue, self._stop_event)
        )
        self._thread.daemon = True
        self._thread.start()

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _run_wrapper(self, q, stop_event):
        try:
            self.run_background(q, stop_event)
        except Exception as exc:  # surfaced to the user, not silently lost
            q.put({"error": str(exc)})

    def modal(self, context, event):
        if event.type == 'ESC':
            self._stop_event.set()
            self._finish(context)
            self.report({'WARNING'}, "Cancelled")
            return {'CANCELLED'}

        if event.type == 'TIMER':
            drained_done = False
            try:
                while True:
                    msg = self._queue.get_nowait()
                    if "error" in msg:
                        self.on_error(context, msg["error"])
                        self._finish(context)
                        self.report({'ERROR'}, msg["error"])
                        return {'CANCELLED'}
                    if "status" in msg or "progress" in msg:
                        self.on_progress(context, msg.get("status"), msg.get("progress"))
                    if msg.get("done"):
                        drained_done = True
            except queue.Empty:
                pass

            for region in context.area.regions if context.area else []:
                region.tag_redraw()

            if drained_done:
                self.on_progress(context, None, 100.0)
                self.on_done(context)
                self._finish(context)
                return {'FINISHED'}

        return {'PASS_THROUGH'}

    def _finish(self, context):
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None


# ---------------------------------------------------------------------------
# Connection test (short + synchronous - a few seconds at most, acceptable
# for a single button click; unlike Generate/Install this is not modal)
# ---------------------------------------------------------------------------

class AHG_OT_test_connection(bpy.types.Operator):
    bl_idname = "ahg.test_connection"
    bl_label = "Test Connection"
    bl_description = "Send a minimal request to the active vision endpoint"

    def execute(self, context):
        prefs = get_prefs(context)

        if prefs.active_mode == 'LOCAL':
            url = prefs.local_endpoint_url.rstrip("/") + "/models"
            headers = {}
        else:
            if prefs.cloud_provider == 'NONE':
                self.report({'ERROR'}, "No cloud provider selected")
                return {'CANCELLED'}
            # TODO: per-provider endpoint + auth header format differ
            # slightly (Authorization: Bearer vs x-api-key, etc.) -
            # fill in per provider in the real client module.
            url = "https://api.example-provider.invalid/v1/models"
            headers = {"Authorization": f"Bearer {prefs.cloud_api_key}"}

        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=3) as resp:
                resp.read(200)
            self.report({'INFO'}, "Connection OK")
        except Exception as exc:
            self.report({'ERROR'}, f"Connection failed: {exc}")
            return {'CANCELLED'}

        return {'FINISHED'}


# ---------------------------------------------------------------------------
# GNM companion environment install (real subprocess flow; the actual
# `pip install` target is a placeholder pending the TensorFlow-vs-NumPy-
# only dependency question from the project brief)
# ---------------------------------------------------------------------------

class AHG_OT_install_gnm_environment(AHG_ModalBackgroundOperator):
    bl_idname = "ahg.install_gnm_environment"
    bl_label = "Install GNM Environment"
    bl_description = "Create a private venv and install Google's GNM shape package into it"

    def invoke(self, context, event):
        prefs = get_prefs(context)
        prefs.gnm_env_running = True
        prefs.gnm_env_status = "Starting..."
        prefs.gnm_env_progress = 0.0
        return super().invoke(context, event)

    def on_progress(self, context, status, progress):
        prefs = get_prefs(context)
        if status is not None:
            prefs.gnm_env_status = status
        if progress is not None:
            prefs.gnm_env_progress = progress

    def on_error(self, context, message):
        prefs = get_prefs(context)
        prefs.gnm_env_status = f"Error: {message}"
        prefs.gnm_env_running = False

    def run_background(self, q, stop_event):
        import subprocess
        import sys
        import venv
        from pathlib import Path

        env_dir = Path(bpy.utils.extension_path_user(__package__, path="gnm_env", create=True))

        q.put({"status": "Creating virtual environment...", "progress": 5})
        _kill_stale_processes_in_dir(env_dir)
        _force_remove_dir(env_dir)  # long-path-safe; see _force_remove_dir
        venv.EnvBuilder(with_pip=True, clear=False).create(str(env_dir))

        pip_exe = env_dir / ("Scripts" if sys.platform == "win32" else "bin") / (
            "pip.exe" if sys.platform == "win32" else "pip"
        )

        q.put({"status": "Installing dependencies...", "progress": 20})
        # Explicit minimal dependency list + --no-deps for GNM itself,
        # rather than letting pip install whatever GNM's package
        # declares. Installing it normally pulled in jupyterlab (almost
        # certainly via its Colab/demo-notebook viewer, not anything the
        # actual model-fitting code needs) and TensorFlow - ballooning
        # the environment, and worse, jupyterlab's deeply-nested asset
        # folders hit Windows' 260-character path limit hard enough to
        # break a later reinstall's cleanup entirely. This list is based
        # on an independently-documented GNM dependency set (a
        # third-party integration's own requirements page), confirmed
        # not to include jupyterlab or any deep-learning framework - if
        # gnm_numpy specifically needs something not listed here, that
        # will surface as an ImportError when the server first tries to
        # use it, and can be added then.
        deps = [
            "numpy", "scipy", "h5py",
            "absl-py", "etils", "immutabledict", "importlib_resources",
            "opt-einsum", "rtree", "tqdm", "typeguard", "opencv-python",
        ]
        result = subprocess.run(
            [str(pip_exe), "install"] + deps,
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            q.put({"error": f"pip install (dependencies) failed: {result.stderr[-500:]}"})
            return

        q.put({"status": "Installing GNM shape package (--no-deps)...", "progress": 60})
        result = subprocess.run(
            [str(pip_exe), "install", "--no-deps",
             "git+https://github.com/google/GNM.git#subdirectory=gnm/shape"],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            q.put({"error": f"pip install (GNM package) failed: {result.stderr[-500:]}"})
            return

        q.put({"status": "Done", "progress": 100, "done": True})

    def on_done(self, context):
        prefs = get_prefs(context)
        prefs.gnm_env_status = "Installed"
        prefs.gnm_env_running = False


# ---------------------------------------------------------------------------
# Landmark-detection environment: MediaPipe has no Python 3.13 wheels as of
# this writing, and Blender 5.1 embeds 3.13 - so this can't be a bundled
# extension wheel like the brief originally assumed. Instead: download a
# self-contained CPython 3.12 build (python-build-standalone, the same
# project `uv` uses), build a venv from THAT interpreter, and install
# MediaPipe there. Fully independent of both Blender's Python and anything
# else already on the user's system.
# ---------------------------------------------------------------------------

_PBS_RELEASES_API = "https://api.github.com/repos/astral-sh/python-build-standalone/releases/latest"
_PBS_TARGET_PY = "3.12"


def _target_triple():
    """Map the running platform to a python-build-standalone target triple."""
    machine = platform.machine().lower()
    is_arm = machine in ("arm64", "aarch64")

    if sys.platform == "win32":
        return "aarch64-pc-windows-msvc" if is_arm else "x86_64-pc-windows-msvc"
    if sys.platform == "darwin":
        return "aarch64-apple-darwin" if is_arm else "x86_64-apple-darwin"
    # linux
    return "aarch64-unknown-linux-gnu" if is_arm else "x86_64-unknown-linux-gnu"


def _find_interpreter(root):
    """Locate the extracted interpreter without assuming an exact internal
    layout - python-build-standalone's own directory structure isn't
    something worth hardcoding blindly."""
    from pathlib import Path
    names = ("python.exe",) if sys.platform == "win32" else ("python3", "python3.12")
    for path in Path(root).rglob("*"):
        if path.name in names and path.is_file():
            return path
    return None


def _safe_unlink(path, attempts=5, delay=0.5):
    """Best-effort cleanup. On Windows, antivirus/indexing can briefly hold
    a lock on a freshly-extracted file - this is not worth failing the
    whole install over, so retry a few times and then just give up,
    leaving the archive on disk (harmless, just a little disk space)."""
    for i in range(attempts):
        try:
            path.unlink(missing_ok=True)
            return
        except PermissionError:
            if i == attempts - 1:
                return  # give up quietly; leftover archive is harmless
            time.sleep(delay)


class AHG_OT_install_landmark_environment(AHG_ModalBackgroundOperator):
    bl_idname = "ahg.install_landmark_environment"
    bl_label = "Install Landmark Environment"
    bl_description = "Download a standalone Python 3.12 and install MediaPipe into a private venv"

    def invoke(self, context, event):
        prefs = get_prefs(context)
        prefs.landmark_env_running = True
        prefs.landmark_env_status = "Starting..."
        prefs.landmark_env_progress = 0.0
        return super().invoke(context, event)

    def on_progress(self, context, status, progress):
        prefs = get_prefs(context)
        if status is not None:
            prefs.landmark_env_status = status
        if progress is not None:
            prefs.landmark_env_progress = progress

    def on_error(self, context, message):
        prefs = get_prefs(context)
        prefs.landmark_env_status = f"Error: {message}"
        prefs.landmark_env_running = False

    def run_background(self, q, stop_event):
        import subprocess
        import venv
        from pathlib import Path

        base_dir = Path(bpy.utils.extension_path_user(__package__, path="landmark_env", create=True))
        interpreter_dir = base_dir / "python_standalone"
        venv_dir = base_dir / "venv"

        interpreter = _find_interpreter(interpreter_dir) if interpreter_dir.exists() else None

        if interpreter is None:
            q.put({"status": "Finding a Python 3.12 build...", "progress": 5})
            triple = _target_triple()
            try:
                req = urllib.request.Request(
                    _PBS_RELEASES_API, headers={"Accept": "application/vnd.github+json"}
                )
                with urllib.request.urlopen(req, timeout=15) as resp:
                    release = json.loads(resp.read())
            except Exception as exc:
                q.put({"error": f"Could not query python-build-standalone releases: {exc}"})
                return

            pattern = re.compile(
                rf"^cpython-{re.escape(_PBS_TARGET_PY)}\.\d+\+\d+-{re.escape(triple)}-install_only\.tar\.gz$"
            )
            asset = next((a for a in release.get("assets", []) if pattern.match(a["name"])), None)
            if asset is None:
                q.put({"error": f"No matching python-build-standalone asset found for {triple}"})
                return

            q.put({"status": f"Downloading {asset['name']}...", "progress": 15})
            interpreter_dir.mkdir(parents=True, exist_ok=True)
            archive_path = base_dir / asset["name"]
            try:
                urllib.request.urlretrieve(asset["browser_download_url"], archive_path)
            except Exception as exc:
                q.put({"error": f"Download failed: {exc}"})
                return

            q.put({"status": "Extracting Python build...", "progress": 40})
            with tarfile.open(archive_path) as tf:
                tf.extractall(interpreter_dir)
            _safe_unlink(archive_path)

            interpreter = _find_interpreter(interpreter_dir)
            if interpreter is None:
                q.put({"error": "Extracted archive but couldn't locate the python executable"})
                return

        if stop_event.is_set():
            return

        q.put({"status": "Creating venv from the standalone interpreter...", "progress": 55})
        _kill_stale_processes_in_dir(venv_dir)
        _force_remove_dir(venv_dir)  # long-path-safe; --clear alone uses shutil.rmtree internally
        # Retries with a short delay: the interpreter was just extracted,
        # and Windows Defender (or similar real-time AV scanning) can
        # briefly lock a freshly-written executable right as venv tries
        # to copy it - the same class of transient lock seen earlier
        # with the downloaded .tar.gz archive, not a real permissions
        # problem.
        result = None
        for attempt in range(5):
            if attempt > 0:
                _force_remove_dir(venv_dir)
            result = subprocess.run(
                [str(interpreter), "-m", "venv", str(venv_dir)],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                break
            time.sleep(1.5)
        if result.returncode != 0:
            q.put({"error": f"venv creation failed after retries: {result.stderr[-500:]}"})
            return

        pip_exe = venv_dir / ("Scripts" if sys.platform == "win32" else "bin") / (
            "pip.exe" if sys.platform == "win32" else "pip"
        )

        q.put({"status": "Installing MediaPipe...", "progress": 75})
        result = subprocess.run(
            [str(pip_exe), "install", "mediapipe"],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            q.put({"error": f"pip install mediapipe failed: {result.stderr[-500:]}"})
            return

        q.put({"status": "Done", "progress": 100, "done": True})

    def on_done(self, context):
        prefs = get_prefs(context)
        prefs.landmark_env_status = "Installed"
        prefs.landmark_env_running = False


# ---------------------------------------------------------------------------
# Photo list management
# ---------------------------------------------------------------------------

class AHG_OT_add_photo(bpy.types.Operator, ImportHelper):
    bl_idname = "ahg.add_photo"
    bl_label = "Add Photo"
    filter_glob: bpy.props.StringProperty(default="*.jpg;*.jpeg;*.png", options={'HIDDEN'})

    def execute(self, context):
        item = context.scene.ahg_props.photos.add()
        item.filepath = self.filepath
        return {'FINISHED'}


class AHG_OT_remove_photo(bpy.types.Operator):
    bl_idname = "ahg.remove_photo"
    bl_label = "Remove Photo"

    def execute(self, context):
        props = context.scene.ahg_props
        if 0 <= props.photos_index < len(props.photos):
            props.photos.remove(props.photos_index)
            props.photos_index = max(0, props.photos_index - 1)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Generate: the actual pipeline entry point. Stages are stubbed with a
# placeholder mesh so the end-to-end flow (and the non-blocking UI) is
# testable before MediaPipe/GNM integration lands.
# ---------------------------------------------------------------------------

class AHG_OT_build_correspondence(AHG_ModalBackgroundOperator):
    bl_idname = "ahg.build_correspondence"
    bl_label = "Build Face Correspondence (Verify)"
    bl_description = (
        "Diagnostic step: computes which GNM mesh vertices correspond to "
        "the 68 reduced landmark points, and places visible markers on "
        "them so you can check the result before it's used for fitting"
    )

    _result = None

    def invoke(self, context, event):
        context.scene.ahg_props.status = "Starting..."
        context.scene.ahg_props.is_running = True
        context.scene.ahg_props.progress = 0.0
        return super().invoke(context, event)

    def run_background(self, q, stop_event):
        q.put({"status": "Starting GNM server...", "progress": 10})
        try:
            gnm_client.ensure_server_running()
        except Exception as exc:
            q.put({"error": f"GNM server unavailable: {exc}"})
            return

        q.put({"status": "Downloading reference face model and aligning (ICP)...", "progress": 30})
        try:
            self._result = gnm_client.build_correspondence()
        except Exception as exc:
            q.put({"error": f"Correspondence build failed: {exc}"})
            return

        q.put({"status": "Done", "progress": 100, "done": True})

    def on_done(self, context):
        result = self._result

        # Reference head so the markers have something to sit on.
        mesh = bpy.data.meshes.new("AHG_Correspondence_Reference")
        mesh.from_pydata(result["template_vertices"], [], result["template_faces"])
        mesh.update()
        ref_obj = bpy.data.objects.new("AHG_Correspondence_Reference", mesh)
        context.collection.objects.link(ref_obj)

        # One small marker sphere per corresponded point, grouped under
        # an empty for easy selection/deletion. Positioned at the head's
        # centroid (not world origin) so Blender's relationship-line
        # overlay doesn't draw a confusing fan down to (0,0,0).
        head_centroid = tuple(np.mean(result["template_vertices"], axis=0))
        parent = bpy.data.objects.new("AHG_Correspondence_Markers", None)
        parent.location = head_centroid
        context.collection.objects.link(parent)

        for i, point in enumerate(result["correspondence_points"]):
            bpy.ops.mesh.primitive_uv_sphere_add(radius=0.003, location=point)
            marker = context.active_object
            marker.name = f"AHG_Landmark_{i:02d}"
            marker.parent = parent
            marker.matrix_parent_inverse = parent.matrix_world.inverted()

        # Diagnostic: the coarse pre-ICP positions too, so it's visible
        # which stage (coarse alignment vs ICP refinement) is at fault
        # if the final result still looks wrong.
        coarse_parent = bpy.data.objects.new("AHG_Correspondence_Coarse", None)
        coarse_parent.location = head_centroid
        context.collection.objects.link(coarse_parent)
        for i, point in enumerate(result["coarse_points"]):
            bpy.ops.mesh.primitive_uv_sphere_add(radius=0.006, location=point)
            marker = context.active_object
            marker.name = f"AHG_Coarse_{i:02d}"
            marker.parent = coarse_parent
            marker.matrix_parent_inverse = coarse_parent.matrix_world.inverted()

        props = context.scene.ahg_props
        props.status = "Done - inspect AHG_Correspondence_Reference + markers before fitting"
        props.is_running = False


class AHG_OT_generate(AHG_ModalBackgroundOperator):
    bl_idname = "ahg.generate"
    bl_label = "Generate"
    bl_description = "Run the photo-to-head pipeline"

    _result_mesh_data = None

    def invoke(self, context, event):
        props = context.scene.ahg_props
        if len(props.photos) == 0:
            self.report({'ERROR'}, "Add at least one photo first")
            return {'CANCELLED'}
        # Read bpy data on the main thread only - the background thread
        # must not touch bpy collections directly.
        self._photo_paths = [item.filepath for item in props.photos]
        props.is_running = True
        props.status = "Starting..."
        props.progress = 0.0
        return super().invoke(context, event)

    def run_background(self, q, stop_event):
        # TODO Phase 1 remaining: GNM fit, texture bake, and export are
        # still stubs below - landmark detection is now real.

        q.put({"status": "Starting landmark server (first run may take a moment)...", "progress": 5})
        try:
            landmark_client.ensure_server_running()
        except Exception as exc:
            q.put({"error": f"Landmark server unavailable: {exc}"})
            return

        if stop_event.is_set():
            return

        photo_paths = self._photo_paths
        all_landmarks = []
        image_dims = []
        for i, path in enumerate(photo_paths):
            q.put({
                "status": f"Detecting landmarks ({i + 1}/{len(photo_paths)})...",
                "progress": 10 + int(30 * (i + 1) / len(photo_paths)),
            })
            try:
                points, width, height = landmark_client.get_landmarks(path)
            except Exception as exc:
                q.put({"error": f"Landmark detection failed on {path}: {exc}"})
                return
            if not points:
                q.put({"error": f"No face detected in {path}"})
                return
            all_landmarks.append(points)
            image_dims.append((width, height))

        self._landmarks = all_landmarks

        if stop_event.is_set():
            return

        q.put({"status": "Starting GNM server (first run may take a moment)...", "progress": 45})
        try:
            gnm_client.ensure_server_running()
        except Exception as exc:
            q.put({"error": f"GNM server unavailable: {exc}"})
            return

        if stop_event.is_set():
            return

        q.put({"status": "Fitting identity to detected landmarks...", "progress": 55})
        try:
            width, height = image_dims[0]
            identity, rmse = gnm_client.fit_identity(all_landmarks[0], width, height)
        except Exception as exc:
            q.put({"error": f"Identity fitting failed: {exc}"})
            return
        self._fit_rmse = rmse

        q.put({"status": f"Generating fitted head mesh (fit RMSE: {rmse:.1f}px)...", "progress": 65})
        try:
            vertices, faces = gnm_client.generate_head(identity=identity)
        except Exception as exc:
            q.put({"error": f"GNM head generation failed: {exc}"})
            return

        self._vertices = vertices
        self._faces = faces

        q.put({"status": "Projecting and baking texture...", "progress": 70})
        time.sleep(0.5)  # placeholder for real texture projection

        q.put({"status": "Preparing export...", "progress": 90})
        time.sleep(0.3)

        q.put({"status": "Done", "progress": 100, "done": True})

    def on_done(self, context):
        mesh = bpy.data.meshes.new("AHG_Head")
        mesh.from_pydata(self._vertices, [], self._faces)
        mesh.update()

        obj = bpy.data.objects.new("AHG_Head", mesh)
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)

        props = context.scene.ahg_props
        props.status = f"Done - {len(self._vertices)} verts, fit RMSE {self._fit_rmse:.1f}px"
        props.is_running = False


# ---------------------------------------------------------------------------
# Registration - note AHG_ModalBackgroundOperator itself is a base class,
# not registered directly; only its concrete subclasses are.
# ---------------------------------------------------------------------------

classes = (
    AHG_OT_test_connection,
    AHG_OT_install_gnm_environment,
    AHG_OT_install_landmark_environment,
    AHG_OT_add_photo,
    AHG_OT_remove_photo,
    AHG_OT_build_correspondence,
    AHG_OT_generate,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
