"""Manages the GNM server subprocess and talks to it over HTTP. Mirrors
landmark_client.py's pattern exactly. Never imports gnm_server.py
directly - that module imports the gnm package, which only exists in the
GNM venv, not in Blender's own Python.
"""

import json
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import bpy

PORT = 8766  # different from the landmark server's 8765
_server_process = None


def _post_json(path, payload, timeout):
    req = urllib.request.Request(
        f"http://127.0.0.1:{PORT}{path}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        # Without this, the server's actual traceback (in the JSON error
        # body) gets silently discarded and all we'd see is "HTTP Error
        # 500: Internal Server Error" - useless for diagnosing anything.
        body = e.read().decode("utf-8", errors="replace")
        try:
            detail = json.loads(body).get("error", body)
        except json.JSONDecodeError:
            detail = body
        raise RuntimeError(f"GNM server error ({e.code}): {detail}") from None


def _venv_python():
    # NOTE: unlike the landmark venv (which lives under a "venv"
    # subdirectory), AHG_OT_install_gnm_environment builds the venv
    # directly at this path - matching that installer's layout.
    venv_dir = Path(bpy.utils.extension_path_user(__package__, path="gnm_env", create=True))
    return venv_dir / ("Scripts" if sys.platform == "win32" else "bin") / (
        "python.exe" if sys.platform == "win32" else "python"
    )


def _server_script_path():
    return Path(__file__).parent / "gnm_server.py"


def _health_check(timeout=1.0):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/health", timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False


def ensure_server_running(startup_timeout=30.0):
    """GNM's first request loads the model asset from disk, which can
    take a few seconds - the health check just confirms the server
    process itself is up and accepting connections, not that the model
    is loaded yet."""
    global _server_process

    if _health_check():
        return

    python_exe = _venv_python()
    if not python_exe.exists():
        raise RuntimeError(
            "GNM environment not installed - use the Preferences panel's "
            "'Install GNM Environment' button first."
        )

    cache_dir = Path(bpy.utils.extension_path_user(__package__, path="gnm_cache", create=True))

    _server_process = subprocess.Popen(
        [str(python_exe), str(_server_script_path()), str(PORT), str(cache_dir)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
    )

    deadline = time.time() + startup_timeout
    while time.time() < deadline:
        if _health_check():
            return
        if _server_process.poll() is not None:
            _, stderr = _server_process.communicate()
            raise RuntimeError(f"GNM server exited during startup: {stderr[-500:]}")
        time.sleep(0.3)

    raise RuntimeError("GNM server did not respond within the startup timeout")


def generate_head(identity=None, expression=None, timeout=60.0):
    """Returns (vertices, faces) as plain Python lists. identity/expression
    are optional lists of floats; omitted means the neutral template."""
    payload = {}
    if identity is not None:
        payload["identity"] = identity
    if expression is not None:
        payload["expression"] = expression
    result = _post_json("/generate", payload, timeout)
    return result["vertices"], result["faces"]


def build_correspondence(timeout=90.0):
    """Returns a dict with gnm_vertex_indices (68 GNM vertex indices, one
    per LM68 landmark), template_vertices, template_faces, and
    correspondence_points (the actual 3D positions of the 68 matched
    vertices, for visualization). Cached server-side after the first call
    - this can take a little while the first time (downloads the
    canonical face model, runs ICP)."""
    return _post_json("/build_correspondence", {}, timeout)


def fit_identity(landmarks_478, image_width, image_height, timeout=180.0):
    """Solves for GNM identity parameters matching the given landmarks
    (full 478-point set from MediaPipe - reduction to the correspondence
    subset happens server-side). Returns (identity, rmse_px) - the RMSE
    is a rough fit-quality signal, not a guarantee of a good match."""
    payload = {
        "landmarks": landmarks_478,
        "image_width": image_width,
        "image_height": image_height,
    }
    result = _post_json("/fit", payload, timeout)
    return result["identity"], result["rmse_px"]


def shutdown_server():
    global _server_process
    if _server_process is not None and _server_process.poll() is None:
        _server_process.terminate()
        try:
            _server_process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            _server_process.kill()
    _server_process = None
