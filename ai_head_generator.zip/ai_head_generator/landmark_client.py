"""Manages the landmark server subprocess and talks to it over HTTP.

Never imports landmark_server.py directly - that module imports mediapipe,
which doesn't exist in Blender's own Python. It's only ever referenced by
file path and run via subprocess, inside the separate landmark venv.
"""

import json
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import bpy

PORT = 8765
_server_process = None


def _post_json(path, payload, timeout):
    req = urllib.request.Request(
        f"http://127.0.0.1:{PORT}{path}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        # Without this, the server's actual traceback (in the JSON error
        # body) gets silently discarded and all we'd see is "HTTP Error
        # 500: Internal Server Error" - useless for diagnosing anything.
        body = e.read().decode("utf-8", errors="replace")
        try:
            detail = json.loads(body).get("error", body)
        except json.JSONDecodeError:
            detail = body
        raise RuntimeError(f"Landmark server error ({e.code}): {detail}") from None


def _venv_python():
    base_dir = Path(bpy.utils.extension_path_user(__package__, path="landmark_env", create=True))
    venv_dir = base_dir / "venv"
    return venv_dir / ("Scripts" if sys.platform == "win32" else "bin") / (
        "python.exe" if sys.platform == "win32" else "python"
    )


def _server_script_path():
    return Path(__file__).parent / "landmark_server.py"


def _health_check(timeout=1.0):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/health", timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False


def ensure_server_running(startup_timeout=20.0):
    """Start the landmark server if it isn't already answering. Raises on
    failure rather than failing silently, since a caller needs to know
    whether landmark detection is actually usable."""
    global _server_process

    if _health_check():
        return

    python_exe = _venv_python()
    if not python_exe.exists():
        raise RuntimeError(
            "Landmark environment not installed - use the Preferences "
            "panel's 'Install Landmark Environment' button first."
        )

    cache_dir = Path(bpy.utils.extension_path_user(__package__, path="landmark_cache", create=True))

    _server_process = subprocess.Popen(
        [str(python_exe), str(_server_script_path()), str(PORT), str(cache_dir)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
    )

    deadline = time.time() + startup_timeout
    while time.time() < deadline:
        if _health_check():
            return
        if _server_process.poll() is not None:
            # Process exited early - surface whatever it printed to stderr.
            _, stderr = _server_process.communicate()
            raise RuntimeError(f"Landmark server exited during startup: {stderr[-500:]}")
        time.sleep(0.3)

    raise RuntimeError("Landmark server did not respond within the startup timeout")


def get_landmarks(image_path, timeout=30.0):
    """Returns (landmarks, width, height). landmarks is a list of [x, y, z]
    normalized coordinates (empty if no face detected). Raises on
    server/network errors - callers should treat that as a real failure,
    not an empty result."""
    result = _post_json("/landmarks", {"image_path": image_path}, timeout)
    return result["landmarks"], result.get("image_width"), result.get("image_height")


def shutdown_server():
    global _server_process
    if _server_process is not None and _server_process.poll() is None:
        _server_process.terminate()
        try:
            _server_process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            _server_process.kill()
    _server_process = None
