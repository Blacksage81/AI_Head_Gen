"""Add-on preferences: local endpoint, cloud provider + masked API key,
active mode, and GNM companion-environment status.

Standard bpy.types.AddonPreferences pattern - the PASSWORD subtype is a
native Blender field mask, not anything specific to any particular tool.
"""

import bpy


CLOUD_PROVIDERS = [
    ('NONE', "None (local only)", "Don't use a cloud vision API"),
    ('ANTHROPIC', "Anthropic", "Use an Anthropic API key"),
    ('OPENAI', "OpenAI", "Use an OpenAI API key"),
    ('GOOGLE', "Google", "Use a Google API key"),
]


class AHG_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    active_mode: bpy.props.EnumProperty(
        name="Vision Model Source",
        items=[
            ('LOCAL', "Local", "Use a local OpenAI-compatible endpoint (e.g. TextGen)"),
            ('CLOUD', "Cloud API", "Use a cloud vision API"),
        ],
        default='LOCAL',
    )

    local_endpoint_url: bpy.props.StringProperty(
        name="Local Endpoint URL",
        description="Base URL of a local OpenAI-compatible chat completions API",
        default="http://127.0.0.1:5000/v1",
    )

    cloud_provider: bpy.props.EnumProperty(
        name="Cloud Provider",
        items=CLOUD_PROVIDERS,
        default='NONE',
    )

    # Masked field - renders as a password input. Never logged, never
    # written anywhere by this add-on other than Blender's own
    # preferences storage.
    cloud_api_key: bpy.props.StringProperty(
        name="API Key",
        subtype='PASSWORD',
        default="",
    )

    cloud_model_name: bpy.props.StringProperty(
        name="Model Name",
        description="Free-text model identifier (e.g. claude-sonnet-4-6, gpt-4o) "
                    "- kept as text since provider catalogs change faster than "
                    "add-on releases",
        default="",
    )

    gnm_env_status: bpy.props.StringProperty(
        name="GNM Environment Status",
        default="Not installed",
    )
    gnm_env_progress: bpy.props.FloatProperty(default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
    gnm_env_running: bpy.props.BoolProperty(default=False)

    landmark_env_status: bpy.props.StringProperty(
        name="Landmark Environment Status",
        default="Not installed",
    )
    landmark_env_progress: bpy.props.FloatProperty(default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
    landmark_env_running: bpy.props.BoolProperty(default=False)

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Vision Model", icon='HIDE_OFF')
        box.prop(self, "active_mode", expand=True)

        if self.active_mode == 'LOCAL':
            row = box.row(align=True)
            row.prop(self, "local_endpoint_url")
            row.operator("ahg.test_connection", text="", icon='PLUGIN')
        else:
            box.prop(self, "cloud_provider")
            if self.cloud_provider != 'NONE':
                box.prop(self, "cloud_api_key")
                box.prop(self, "cloud_model_name")
                row = box.row(align=True)
                row.operator("ahg.test_connection", text="Test Connection", icon='PLUGIN')

        box2 = layout.box()
        box2.label(text="GNM Companion Environment", icon='MESH_MONKEY')
        row = box2.row()
        row.label(text=f"Status: {self.gnm_env_status}")
        row.enabled = not self.gnm_env_running
        row.operator("ahg.install_gnm_environment", text="Install / Update")
        if self.gnm_env_running:
            row2 = box2.row()
            row2.enabled = False
            row2.prop(self, "gnm_env_progress", text="", slider=True)

        box3 = layout.box()
        box3.label(text="Landmark Environment (standalone Python 3.12 + MediaPipe)", icon='TRACKING_FORWARDS')
        row = box3.row()
        row.label(text=f"Status: {self.landmark_env_status}")
        row.enabled = not self.landmark_env_running
        row.operator("ahg.install_landmark_environment", text="Install / Update")
        if self.landmark_env_running:
            row3 = box3.row()
            row3.enabled = False
            row3.prop(self, "landmark_env_progress", text="", slider=True)


def get_prefs(context):
    return context.preferences.addons[__package__].preferences


classes = (AHG_AddonPreferences,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
