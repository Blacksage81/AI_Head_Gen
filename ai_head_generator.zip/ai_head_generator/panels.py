import bpy


class AHG_UL_photos(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        layout.label(text=item.filepath, icon='IMAGE_DATA')


class AHG_PT_main(bpy.types.Panel):
    bl_label = "AI Head Generator"
    bl_idname = "AHG_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Head Gen"

    def draw(self, context):
        layout = self.layout
        props = context.scene.ahg_props

        col = layout.column()
        col.label(text="Source Photos")
        row = col.row()
        row.template_list(
            "AHG_UL_photos", "", props, "photos", props, "photos_index", rows=4
        )
        col2 = row.column(align=True)
        col2.operator("ahg.add_photo", text="", icon='ADD')
        col2.operator("ahg.remove_photo", text="", icon='REMOVE')

        layout.separator()

        row = layout.row()
        row.scale_y = 1.5
        row.enabled = not props.is_running
        row.operator("ahg.generate", text="Generate", icon='PLAY')

        row2 = layout.row()
        row2.enabled = not props.is_running
        row2.operator("ahg.build_correspondence", text="Build Face Correspondence (Verify)", icon='SHADERFX')

        if props.is_running or props.progress > 0:
            box = layout.box()
            box.label(text=props.status)
            row = box.row()
            row.enabled = False
            row.prop(props, "progress", text="", slider=True)


classes = (
    AHG_UL_photos,
    AHG_PT_main,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
