"""AI Head Generator - extension entry point.

Registration order matters: properties before panels/operators that
reference context.scene.ahg_props, preferences before operators that
call get_prefs().
"""

from . import properties
from . import preferences
from . import operators
from . import panels
from . import landmark_client
from . import gnm_client

_modules = (properties, preferences, operators, panels)


def register():
    for mod in _modules:
        mod.register()


def unregister():
    for mod in reversed(_modules):
        mod.unregister()
    # Don't leave companion server subprocesses running after Blender
    # closes or the add-on is disabled.
    landmark_client.shutdown_server()
    gnm_client.shutdown_server()
