"""Scene-level state for the AI Head Generator.

Kept deliberately small for the Phase 1 scaffold: a list of source photos,
and a status/progress pair the modal operator updates while it runs.
"""

import bpy


class AHG_PhotoItem(bpy.types.PropertyGroup):
    filepath: bpy.props.StringProperty(
        name="Photo",
        description="Path to a source photo of the character's face",
        subtype='FILE_PATH',
    )


class AHG_SceneProperties(bpy.types.PropertyGroup):
    photos: bpy.props.CollectionProperty(type=AHG_PhotoItem)
    photos_index: bpy.props.IntProperty(default=0)

    status: bpy.props.StringProperty(
        name="Status",
        default="Idle",
    )
    progress: bpy.props.FloatProperty(
        name="Progress",
        subtype='PERCENTAGE',
        min=0.0,
        max=100.0,
        default=0.0,
    )
    is_running: bpy.props.BoolProperty(default=False)


classes = (
    AHG_PhotoItem,
    AHG_SceneProperties,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.ahg_props = bpy.props.PointerProperty(type=AHG_SceneProperties)


def unregister():
    del bpy.types.Scene.ahg_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
