"""Runs INSIDE the GNM venv, never inside Blender's own process - same
reasoning as landmark_server.py: isolate the heavy/version-sensitive
dependency in its own environment rather than importing it directly into
Blender's embedded Python.

Phase 1 scope: generate a mesh from explicit identity/expression
parameters (defaulting to the neutral template if none given). No
landmark-based fitting yet - that's the next step once this round-trip
is proven.
"""

import json
import sys
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np
from gnm.shape import gnm_numpy


_gnm_model = None
_gnm_lock = threading.Lock()
_correspondence_cache = None
_IDENTITY_REG_ALPHA = 0.02  # lowered from 0.3 - hard bounds now do the safety job (see below), regularization just needs to prefer smaller solutions among those that fit similarly well, not prevent runaway. 0.3 was calibrated for the unbounded case and, once bounds were added, was strong enough to suppress all movement (fit stayed at neutral, RMSE got worse not better).
_IDENTITY_SUBSPACE_DIM = 48  # matches the independently-validated GNM-Studio approach

_CANONICAL_MODEL_URL = (
    "https://raw.githubusercontent.com/google/mediapipe/master/"
    "mediapipe/modules/face_geometry/data/canonical_face_model.obj"
)

# A well-established community mapping from MediaPipe's 478-point face
# mesh onto a reduced, stable 68-point scheme (jawline, brows, nose, eyes,
# mouth) - the same scale independently used by other GNM photo-fitting
# tools. Indices apply directly to canonical_face_model.obj since it
# shares MediaPipe's 468-point topology (the 478-point Face Landmarker
# output just appends 10 iris points on top, which this set deliberately
# excludes - iris tracking isn't relevant to identity shape fitting).
_YAW_IDX = [356, 454, 361, 288, 397, 379, 378, 377, 152, 148, 149, 150, 172, 58, 132, 234, 127]
_BROW_IDX = [70, 63, 105, 66, 107, 336, 296, 334, 293, 300]
_NOSE_IDX = [6, 5, 1, 2, 129, 240, 460, 358]
_EYE_IDX = [33, 160, 158, 133, 153, 144, 362, 385, 387, 263, 373, 380]
_MOUTH_IDX = [78, 191, 80, 81, 82, 13, 312, 311, 310, 415, 308, 324, 318, 402, 317, 14, 87, 178, 88, 95]
LM68_MEDIAPIPE_INDICES = list(dict.fromkeys(_YAW_IDX + _BROW_IDX + _NOSE_IDX + _EYE_IDX + _MOUTH_IDX))


def _ensure_canonical_model(cache_dir: Path) -> Path:
    cache_dir.mkdir(parents=True, exist_ok=True)
    path = cache_dir / "canonical_face_model.obj"
    if not path.exists():
        urllib.request.urlretrieve(_CANONICAL_MODEL_URL, path)
    return path


def _parse_obj_vertices(path: Path) -> np.ndarray:
    verts = []
    with open(path) as f:
        for line in f:
            if line.startswith("v "):
                verts.append([float(x) for x in line.split()[1:4]])
    return np.array(verts)


def _umeyama(src, dst):
    """Closed-form similarity transform (rotation + uniform scale +
    translation) minimizing ||scale * R @ src.T + t - dst.T||^2.
    Standard Umeyama's method via SVD."""
    src_mean, dst_mean = src.mean(axis=0), dst.mean(axis=0)
    src_c, dst_c = src - src_mean, dst - dst_mean
    cov = (dst_c.T @ src_c) / len(src)
    U, S, Vt = np.linalg.svd(cov)
    d = np.sign(np.linalg.det(U @ Vt))
    D = np.diag([1, 1, d])
    R = U @ D @ Vt
    var_src = (src_c ** 2).sum() / len(src)
    scale = np.trace(np.diag(S) @ D) / var_src
    t = dst_mean - scale * R @ src_mean
    return scale, R, t


def _icp_align(src_points, target_points, iterations=20):
    """Rigid+scale ICP: repeatedly match src_points to their nearest
    target_points, refit the similarity transform, repeat. Brute-force
    nearest neighbor (fine at this scale - dozens of query points against
    thousands of target vertices)."""
    scale, R, t = 1.0, np.eye(3), np.zeros(3)
    current = src_points.copy()

    for _ in range(iterations):
        # Nearest target vertex per current point.
        dists = np.linalg.norm(target_points[None, :, :] - current[:, None, :], axis=2)
        nearest = target_points[dists.argmin(axis=1)]

        scale, R, t = _umeyama(src_points, nearest)
        current = (scale * (R @ src_points.T).T) + t

    dists = np.linalg.norm(target_points[None, :, :] - current[:, None, :], axis=2)
    nearest_idx = dists.argmin(axis=1)
    return nearest_idx, current


def _head_region_mask(template_verts, top_fraction=0.7):
    """Excludes the neck from ICP's candidate pool entirely. Confirmed
    convention: face-forward is +Z, chin direction is -Y, so the
    neck-to-crown vertical axis is Y (not Z) - the neck sits at the
    low-Y extreme, near the chin/jaw and below."""
    y = template_verts[:, 1]
    threshold = np.quantile(y, 1 - top_fraction)
    return y >= threshold


def _estimate_frame(points, forward_point, down_point):
    """Empirically determines a point cloud's own forward/down/right axes
    using two known semantic points (nose tip, chin), rather than
    assuming a fixed convention that might not match reality."""
    centroid = points.mean(axis=0)
    forward = forward_point - centroid
    forward = forward / np.linalg.norm(forward)
    down_raw = down_point - centroid
    down = down_raw - np.dot(down_raw, forward) * forward  # orthogonalize
    down = down / np.linalg.norm(down)
    right = np.cross(down, forward)
    right = right / np.linalg.norm(right)
    return centroid, np.stack([forward, down, right])


def _coarse_align(canonical_verts, reduced_canonical, gnm_head_verts):
    """Self-calibrating coarse pre-alignment: figures out the canonical
    model's own forward/down axes from its known nose-tip/chin landmarks,
    then rotates+scales+translates onto GNM's confirmed convention
    (-Y forward, +Z up) so ICP starts close to the right answer instead
    of an ungrounded guess."""
    nose_tip = canonical_verts[1]
    chin = canonical_verts[152]
    centroid_c, basis_c = _estimate_frame(canonical_verts, nose_tip, chin)

    # Confirmed convention (not assumed): face-forward is +Z, chin
    # direction (down, relative to face centroid) is -Y.
    forward_g = np.array([0.0, 0.0, 1.0])
    down_g = np.array([0.0, -1.0, 0.0])
    right_g = np.cross(down_g, forward_g)
    basis_g = np.stack([forward_g, down_g, right_g])

    R = basis_g.T @ basis_c  # maps canonical-frame directions onto GNM's frame

    scale = (
        np.linalg.norm(gnm_head_verts.max(axis=0) - gnm_head_verts.min(axis=0))
        / np.linalg.norm(canonical_verts.max(axis=0) - canonical_verts.min(axis=0))
    )

    aligned = scale * (R @ (reduced_canonical - centroid_c).T).T
    aligned += gnm_head_verts.mean(axis=0)
    return aligned


def _build_correspondence(cache_dir: Path):
    global _correspondence_cache
    if _correspondence_cache is not None:
        return _correspondence_cache

    gnm = _get_model()
    canonical_path = _ensure_canonical_model(cache_dir)
    canonical_verts = _parse_obj_vertices(canonical_path)
    reduced_canonical = canonical_verts[LM68_MEDIAPIPE_INDICES]

    template_verts = gnm.template_vertex_positions
    head_mask = _head_region_mask(template_verts)
    head_verts = template_verts[head_mask]
    head_orig_indices = np.nonzero(head_mask)[0]

    coarse_aligned = _coarse_align(canonical_verts, reduced_canonical, head_verts)
    nearest_in_head, icp_final = _icp_align(coarse_aligned, head_verts)
    gnm_indices = head_orig_indices[nearest_in_head]

    _correspondence_cache = {
        "gnm_vertex_indices": [int(i) for i in gnm_indices],
        "coarse_points": coarse_aligned.tolist(),  # pre-ICP, for diagnosis
    }
    return _correspondence_cache


def _get_model():
    global _gnm_model
    with _gnm_lock:
        if _gnm_model is None:
            _gnm_model = gnm_numpy.GNM.from_local(
                version=gnm_numpy.GNMMajorVersion.V3,
                variant=gnm_numpy.GNMVariant.HEAD,
            )
    return _gnm_model


def _fit_identity(cache_dir: Path, landmarks_478, image_width, image_height):
    """Solves for GNM identity parameters (and a weak-perspective camera
    scale/offset) that minimize 2D reprojection error against the
    detected landmarks. Expression held at zero - single-image, roughly
    frontal photo scope, per the project's current phase.

    Only fits the first _IDENTITY_SUBSPACE_DIM components, not the full
    ~170-253 - matching the same reduced-subspace approach an independent
    GNM tool converged on. This isn't just a speed optimization: fitting
    the full dimensionality with a numerically-estimated (finite
    difference) Jacobian requires roughly one extra model evaluation per
    parameter per iteration, which made the full-size fit far too slow
    to complete before timing out - and a single-threaded HTTP server
    meant that runaway fit blocked even simple health checks in the
    meantime (fixed separately by switching to ThreadingHTTPServer).
    """
    import scipy.optimize

    gnm = _get_model()
    corr = _build_correspondence(cache_dir)
    gnm_indices = corr["gnm_vertex_indices"]

    all_landmarks = np.array(landmarks_478)
    target_2d = all_landmarks[LM68_MEDIAPIPE_INDICES][:, :2]
    target_px = target_2d * np.array([image_width, image_height])
    target_px[:, 1] = -target_px[:, 1]
    target_px -= target_px.mean(axis=0)

    # Regularization weight is scaled to this photo's actual pixel
    # spread, not a fixed constant - a fixed weight would be arbitrarily
    # mismatched against different image resolutions/framings. This
    # replaces an earlier version that used weight=1.0 directly against
    # identity parameters while pixel residuals were in the hundreds -
    # a scale mismatch of roughly two orders of magnitude that let the
    # optimizer push parameters to extreme, unrealistic values while
    # barely denting the regularization penalty.
    reg_weight = _IDENTITY_REG_ALPHA * float(np.std(target_px))

    rotations = np.zeros((gnm.num_joints, 3))
    translation = np.zeros((3,))
    expression = np.zeros(gnm.expression_dim)
    full_identity_dim = gnm.identity_dim
    n_fit = min(_IDENTITY_SUBSPACE_DIM, full_identity_dim)

    from scipy.spatial.transform import Rotation

    def project(identity_reduced, cam_scale, cam_offset, pose_rotvec):
        identity_full = np.zeros(full_identity_dim)
        identity_full[:n_fit] = identity_reduced
        vertices = gnm(identity_full, expression, rotations, translation)
        pts_3d = vertices[gnm_indices]
        # Rigid head-pose rotation. Added after discovering that bounded
        # fits (identity params constrained to GNM's documented -3..+3
        # range) plateaued around RMSE~100px regardless of regularization
        # strength, while only letting parameters go unrealistically
        # extreme (unbounded) could reach RMSE~50px - the signature of
        # an un-modeled degree of freedom (head tilt), not a shape
        # problem identity alone could fix. A photo need not be exactly
        # frontal.
        R = Rotation.from_rotvec(pose_rotvec).as_matrix()
        pts_3d = pts_3d @ R.T
        pts_2d = pts_3d[:, :2] * np.array([1.0, -1.0])
        return cam_scale * pts_2d + cam_offset

    def residuals(params):
        identity_reduced = params[:n_fit]
        cam_scale = params[n_fit]
        cam_offset = params[n_fit + 1:n_fit + 3]
        pose_rotvec = params[n_fit + 3:n_fit + 6]
        data_res = (project(identity_reduced, cam_scale, cam_offset, pose_rotvec) - target_px).ravel()
        reg_res = reg_weight * identity_reduced
        return np.concatenate([data_res, reg_res])

    neutral_pts = project(np.zeros(n_fit), 1.0, np.zeros(2), np.zeros(3))
    init_scale = (
        np.linalg.norm(target_px.max(axis=0) - target_px.min(axis=0))
        / max(np.linalg.norm(neutral_pts.max(axis=0) - neutral_pts.min(axis=0)), 1e-6)
    )
    x0 = np.concatenate([np.zeros(n_fit), [init_scale], [0.0, 0.0], [0.0, 0.0, 0.0]])

    # Hard bounds matching GNM's own documented "Typical Range: -3 to +3"
    # for identity parameters - soft regularization alone wasn't enough
    # to keep the optimizer inside the range the model was actually
    # designed/validated for (observed fits pushing components to 4-6x
    # that range, which produced results with no resemblance to a human
    # face). Camera scale/offset stay unbounded (scale just needs to
    # stay positive). Pose rotation loosely bounded to roughly +/-45
    # degrees per axis - enough for real photo variation, not enough to
    # let rotation alone fake an entirely different fit.
    lower = np.concatenate([[-3.0] * n_fit, [1e-6], [-np.inf, -np.inf], [-0.8, -0.8, -0.8]])
    upper = np.concatenate([[3.0] * n_fit, [np.inf], [np.inf, np.inf], [0.8, 0.8, 0.8]])

    # max_nfev kept at 500 (not raised further) despite adding 3 more
    # parameters - a live test at max_nfev=800 took over 4 minutes to
    # converge, which is a bad experience for a UI button even though it
    # eventually produced a good result. This is a real tradeoff between
    # thoroughness and responsiveness worth revisiting.
    result = scipy.optimize.least_squares(
        residuals, x0, method="trf", max_nfev=500, bounds=(lower, upper)
    )
    identity_fit_full = np.zeros(full_identity_dim)
    identity_fit_full[:n_fit] = result.x[:n_fit]
    data_residuals = result.fun[:target_px.size]
    return identity_fit_full.tolist(), float(np.mean(data_residuals ** 2) ** 0.5)


class Handler(BaseHTTPRequestHandler):
    cache_dir = None  # set in main()

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self._send_json(200, {"status": "ok"})
        else:
            self._send_json(404, {"error": "not found"})

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length)) if length else {}
            gnm = _get_model()

            if self.path == "/generate":
                identity = (
                    np.array(body["identity"], dtype=np.float64)
                    if "identity" in body else np.zeros(gnm.identity_dim)
                )
                expression = (
                    np.array(body["expression"], dtype=np.float64)
                    if "expression" in body else np.zeros(gnm.expression_dim)
                )
                rotations = np.zeros((gnm.num_joints, 3))
                translation = np.zeros((3,))
                vertices = gnm(identity, expression, rotations, translation)
                self._send_json(200, {
                    "vertices": vertices.tolist(),
                    "faces": gnm.triangles.tolist(),
                })

            elif self.path == "/build_correspondence":
                result = _build_correspondence(self.cache_dir)
                gnm_indices = result["gnm_vertex_indices"]
                template_verts = gnm.template_vertex_positions
                self._send_json(200, {
                    "gnm_vertex_indices": gnm_indices,
                    "template_vertices": template_verts.tolist(),
                    "template_faces": gnm.triangles.tolist(),
                    "correspondence_points": template_verts[gnm_indices].tolist(),
                    "coarse_points": result["coarse_points"],
                })

            elif self.path == "/fit":
                identity, rmse = _fit_identity(
                    self.cache_dir, body["landmarks"], body["image_width"], body["image_height"]
                )
                self._send_json(200, {"identity": identity, "rmse_px": rmse})

            else:
                self._send_json(404, {"error": "not found"})
        except Exception as exc:
            self._send_json(500, {"error": str(exc)})

    def log_message(self, format, *args):
        pass


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8766
    cache_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path.home() / ".ahg_cache"
    Handler.cache_dir = cache_dir

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.serve_forever()


if __name__ == "__main__":
    main()
